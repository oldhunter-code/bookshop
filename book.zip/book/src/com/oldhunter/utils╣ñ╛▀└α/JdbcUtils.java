package com.oldhunter.utils工具类;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidDataSourceFactory;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;


public class JdbcUtils {
    private static DruidDataSource dataSource;
    //用ThreadLocal 关联Connection对象，保证统同一个线程内可以获得同一个Connection
    private static  ThreadLocal<Connection> conns= new ThreadLocal<>();


    static {
        Properties properties = new Properties();
        //读取配置文件信息,类加载器获取流
        InputStream resourceAsStream = JdbcUtils.class.getClassLoader().getResourceAsStream("jdbc.properties");
        try {
            properties.load(resourceAsStream);
            dataSource = (DruidDataSource) DruidDataSourceFactory.createDataSource(properties);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    /**
     * 获取数据库连接池的连接
     * 如果返回null说明获取连接失败
     * @return
     */
    public static Connection getConnection() {
        Connection connection=conns.get();
         //第一次从ThreadLocal获取连接为空时,从datasource获取连接对象
        if (connection==null){
            try {
                connection=dataSource.getConnection();
                conns.set(connection);//保存到ThreadLocal中
                connection.setAutoCommit(false);//设置事务手动提交
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return connection;
    }

    /**
     * 提交事务并关闭释放连接
     */
    public static void commitAndClose(){
        Connection connection = conns.get();
        if (connection!=null){
            try {
                //提交事务
                connection.commit();

            } catch (SQLException e) {
                e.printStackTrace();
            }finally {
                try {
                    //关闭连接
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        //执行remove操作，因为tomcat服务器底层使用了线程池，不remove会出错
        conns.remove();

    }
    /**
     * 回滚事务并关闭释放连接
     */
    public static void rollbackAndClose(){
      Connection connection = conns.get();
      if (connection!=null){
          try {
              //回滚事务
              connection.rollback();

          } catch (SQLException e) {
              e.printStackTrace();
          }finally {
              try {
                  //关闭连接
                  connection.close();
              } catch (SQLException e) {
                  e.printStackTrace();
              }
          }
      }
      //执行remove操作，防止内存泄漏
      conns.remove();
    }
     //其他dao不再执行关闭连接操作，等到事务提交或者回滚再统一关闭连接

//    /**
//     * 关闭连接
//     *
//     * @param connection
//     */
//    public static void close(Connection connection) {
//        if (connection!=null){
//            try {
//                connection.close();
//            } catch (SQLException e) {
//                e.printStackTrace();
//            }
//        }
//    }
}
