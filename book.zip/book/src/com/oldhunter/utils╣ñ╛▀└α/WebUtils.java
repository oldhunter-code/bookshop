package com.oldhunter.utils工具类;

import org.apache.commons.beanutils.BeanUtils;

import java.util.Map;

public class WebUtils {
    /**
     * 把Map中的值注入对应的到bean
     * @param value
     * @param bean
     * 这个方法可以方便的解决dao service web 三个层中参数过多的问题，一次性把map的参数都传给bean对象
     * 但是要求map中参数名称和bean对象中的参数名称一致
     */
    public static <T> T copyParamToBean(Map value, T bean){
        try {
            //把请求的所有参数都注入到bean对象中,注入原理是通过我们定义的pojobean类的set方法来注入的
            BeanUtils.populate(bean,value);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return bean;
    }
    public static int parseInt(String str ,int defaultValue){
        try {
            return Integer.parseInt(str);
        } catch (NumberFormatException e) {
        //    e.printStackTrace();
        }
        return defaultValue;
    }
}
