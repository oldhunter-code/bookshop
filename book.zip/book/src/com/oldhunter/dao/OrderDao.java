package com.oldhunter.dao;

import com.oldhunter.pojobean.Order;

public interface OrderDao {
    int saveOrder(Order order);
}
