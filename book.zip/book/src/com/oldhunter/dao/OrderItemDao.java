package com.oldhunter.dao;

import com.oldhunter.pojobean.OrderItem;

public interface OrderItemDao {
    int saveOrderItem(OrderItem orderItem);
}
