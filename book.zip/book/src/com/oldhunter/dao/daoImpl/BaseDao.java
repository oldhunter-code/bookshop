package com.oldhunter.dao.daoImpl;

import com.oldhunter.utils工具类.JdbcUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public abstract class
BaseDao {
    private QueryRunner queryRunner=new QueryRunner();

    /**
     *  update()用于执行 insert和update或者delete
     *  传入参数 sql语句 可变长参数
     *
     *  返回其他表示执行的行数
     */
    public int update(String sql,Object ... args){
        Connection connection= JdbcUtils.getConnection();
        try {
            //该函数返回一个int，表示执行的记录数
            return queryRunner.update(connection,sql,args);

        } catch (SQLException e) {
            e.printStackTrace();
            //使用ThreadLocal后,必须要把捕获的异常抛出，否则其他程序无法得知发生异常，回滚事务
            throw  new  RuntimeException(e);
        }

    }

    /**
     *  查询返回一个javaBean的sql语句
     * @param type 返回的对象类型
     * @param sql   执行的sql
     * @param args   sql的参数值
     * @param <T>    返回的类型的泛型
     * @return
     *     共出现了三个T，第一个是用来声明类型参数的，后面的两个才是泛型的实现。
     */
    public <T>T queryForone(Class<T> type,String sql,Object ... args){
        Connection connection=JdbcUtils.getConnection();
        try {
            return queryRunner.query(connection,sql,new BeanHandler<T>(type),args);
        } catch (SQLException e) {
            e.printStackTrace();
            throw  new  RuntimeException(e);
        }

    }

    /**
     * 查询返回多个javaBean结果的sql语句
     * @param type
     * @param sql
     * @param args
     * @param <T>
     * @return
     */
    public <T>List<T>  quertForList(Class<T> type,String sql ,Object ... args ){
        Connection connection =JdbcUtils.getConnection();
        try {
            return queryRunner.query(connection,sql,new BeanListHandler<T>(type),args);
        } catch (SQLException e) {
            e.printStackTrace();
            throw  new  RuntimeException(e);
        }

    }

    /**
     * 查询返回一行一列结果的sql,原子性查询
     * @param sql
     * @param args
     * @return
     */
    public Object queryForSingleValue(String sql,Object ... args){
        Connection connection = JdbcUtils.getConnection();
        try {
           return queryRunner.query(connection,sql,new ScalarHandler(),args);
        } catch (SQLException e) {
            e.printStackTrace();
            throw  new  RuntimeException(e);
        }

    }
}
