package com.oldhunter.dao;

import com.oldhunter.pojobean.User;

public interface UserDao {
    //快速生成接口测试类的方法 ctrl+shift+t

    /**
     * 根据用户名查询用户信息
     *
     * @param username
     * @return 返回null说明没有该用户
     */
    User queryUserByUsername(String username);

    /**
     * 根据用户信息和密码查询用户信息
     *
     * @param username
     * @param password
     * @return 回null说明用户名错误或者密码错误
     */
    User queryUserByUsernameAndPassword(String username, String password);

    /**
     * 保存用户信息
     *
     * @param user
     * @return 返回-1是失败 返回其他是影响的行数
     */
    int saveUser(User user);


}
