package com.oldhunter.web;

import com.google.gson.Gson;
import com.oldhunter.pojobean.User;
import com.oldhunter.service.UserService;
import com.oldhunter.service.serviceImp.UserServiceImpl;
import com.oldhunter.utils工具类.WebUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static com.google.code.kaptcha.Constants.KAPTCHA_SESSION_KEY;


@WebServlet(name = "UserServlet", urlPatterns = "/userServlet")
public class UserServlet extends BaseServlet {
    private UserService userService = new UserServiceImpl();
    //继承了抽象类BaseServlet的doPost方法（非抽象方法），tomcat服务器收到post请求后，会调用父类的方法

    /**
     * ajax请求检查用户名是否已存在
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void ajaxExistUsername(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       //获取ajax发送过来的请求参数
        String username=req.getParameter("username");
        //调用service层的方法
        boolean existUsername=userService.existUsername(username);
        Map<String,Object> resultMap = new HashMap<>();
        resultMap.put("existUsername",existUsername);
        Gson gson = new Gson();
        String json =gson.toJson(resultMap);
        //把响应输出的客户端
        resp.getWriter().write(json);
    }

    /**
     * 登录的方法
     *
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void login(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        User loginUser = userService.login(new User(null, username, password, null));
        if (loginUser != null) {
            //把登录成功的用户信息放入session域
            req.getSession().setAttribute("user", loginUser);
            req.getRequestDispatcher("/pages/user/login_success.jsp").forward(req, resp);
        } else {
            //如果登录失败，把错误信息和回显的表单项信息保存到request域
            req.setAttribute("errormsg", "用户名或者密码错误");
            req.setAttribute("username", username);
            // System.out.println("密码或者用户名有误");
            //跳转回登录页面
            req.getRequestDispatcher("/pages/user/login.jsp").forward(req, resp);

        }
    }

    /**
     * 注销的方法
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void logout(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
         //使session过期
        req.getSession().invalidate();
        //重定向到登录页面
        resp.sendRedirect(req.getContextPath());
    }

    /**
     * 注册的方法
     *
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void regist(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取session中的验证码
        String token = (String) req.getSession().getAttribute(KAPTCHA_SESSION_KEY);
        //删除session中的验证码信息
        req.getSession().removeAttribute(KAPTCHA_SESSION_KEY);

        //获取请求的参数
        User user = WebUtils.copyParamToBean(req.getParameterMap(), new User());

        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String email = req.getParameter("email");
        String code = req.getParameter("code");


        //检查验证码是否正确 ，忽略大小写
        if (token!=null&&token.equalsIgnoreCase(code)) {
            //验证码验证成功,检查用户名是否可用
            if (userService.existUsername(username)) {
                //System.out.println("用户名[" + username + "]已存在");
                //如果用户名已存在，返回回显信息
                req.setAttribute("errormsg", "用户名已存在");
                req.setAttribute("username", user.getUsername());
                req.setAttribute("password", user.getPassword());
                req.setAttribute("email", user.getEmail());
                req.getRequestDispatcher("/pages/user/regist.jsp").forward(req, resp);
            } else {
                //可用,执行注册
                userService.registUser(new User(null, username, password, email));
                //跳转到成功注册页面
                req.getRequestDispatcher("/pages/user/regist_success.jsp").forward(req, resp);
            }

        } else {//验证码不正确 ，跳回注册页面，并显示回显信息
            req.setAttribute("errormsg", "验证码错误");
            req.setAttribute("username", username);
            req.setAttribute("password", password);
            req.setAttribute("email", email);
            // System.out.println("验证码[" + code + "]错误");
            req.getRequestDispatcher("/pages/user/regist.jsp").forward(req, resp);

        }
    }
}
