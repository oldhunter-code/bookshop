package com.oldhunter.web;

import com.oldhunter.pojobean.Book;
import com.oldhunter.pojobean.Page;
import com.oldhunter.service.BookService;
import com.oldhunter.service.serviceImp.BookServiceImpl;
import com.oldhunter.utils工具类.WebUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
@WebServlet(name = "ClientBookServlet",urlPatterns = "/client/bookServlet")
public class ClientBookServlet extends BaseServlet {
    BookService bookService=new BookServiceImpl();
    /**
     * 处理分页功能
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void page(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //1获取请求的参数 pageNo pageSize, 默认第一页开始展示
        int pageNo = WebUtils.parseInt(req.getParameter("pageNo"),1);
        int pageSize =WebUtils.parseInt(req.getParameter("pageSize"), Page.PAGE_SIZE);
        //2调用BookService.page(pageNo,pageSize) 获得page对象
        Page<Book> page = bookService.page(pageNo,pageSize);
        //设置page的url
        page.setUrl("client/bookServlet?action=page");
        //保存page对象到request域
        req.setAttribute("page",page);
        //请求转发到 pages/manager/book_manager.jsp
        req.getRequestDispatcher("/pages/client/index.jsp").forward(req,resp);
    }
    /**
     * 处理按价格范围分页功能
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void pageByPrice(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //1获取请求的参数 pageNo pageSize, 默认第一页开始展示
        int pageNo = WebUtils.parseInt(req.getParameter("pageNo"),1);
        int pageSize =WebUtils.parseInt(req.getParameter("pageSize"), Page.PAGE_SIZE);
        int min=WebUtils.parseInt(req.getParameter("min"),0);
        int max=WebUtils.parseInt(req.getParameter("max"),Integer.MAX_VALUE);
        //2调用BookService.page(pageNo,pageSize) 获得page对象
        Page<Book> page = bookService.pageByPrice(pageNo,pageSize,min,max);
        //设置page的url
        StringBuffer sb = new StringBuffer("client/bookServlet?action=pageByPrice");
        if (req.getParameter("min")!=null){
            sb.append("&min=").append(req.getParameter("min"));
        }
        if (req.getParameter("max")!=null){
            sb.append("&max=").append(req.getParameter("max"));
        }
        page.setUrl(sb.toString());
        //保存page对象到request域
        req.setAttribute("page",page);
        //请求转发到 pages/manager/book_manager.jsp
        req.getRequestDispatcher("/pages/client/index.jsp").forward(req,resp);
    }
}
