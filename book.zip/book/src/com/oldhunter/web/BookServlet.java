package com.oldhunter.web;

import com.oldhunter.pojobean.Book;
import com.oldhunter.pojobean.Page;
import com.oldhunter.service.BookService;
import com.oldhunter.service.serviceImp.BookServiceImpl;
import com.oldhunter.utils工具类.WebUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "BookServlet",urlPatterns = "/manager/bookServlet")
public class BookServlet extends BaseServlet {
    private BookService bookService=new BookServiceImpl();
    /**
     * 增加图书
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void add(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
         //1获取请求的参数，封装成bean对象
        System.out.println(req.getParameter("name"));
        Book book = WebUtils.copyParamToBean(req.getParameterMap(),new Book());

         //2调用BookService保存图书信息到数据库
        bookService.addBook(book);
         //3跳转回图书管理页面
        //这种请求转发跳转会有bug，浏览器会记录最后一次请求的所有信息，当用户刷新图书管理页面，会提交最后一次请求，然后就会再次提交表单，重复添加。
       // req.getRequestDispatcher("/manager/bookServlet?action=list").forward(req,resp);
        //应该用重定向转发，重定向的相对路径是到端口号，所以需要加上工程名
        //希望添加图书后返回最后一页，由于我们设置过pageNo大于pageTotal时，pageNo等于pageTotal
        // 所以这里可以设置pageNo为pageTotal+1，解决添加图书后，解决总页数发生+1的情况
        int pageNo=WebUtils.parseInt(req.getParameter("pageNo"),0);
        pageNo=pageNo+1;
        resp.sendRedirect(req.getContextPath()+"/manager/bookServlet?action=page&pageNo="+pageNo);

    }

    /**
     * 删除图书
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void delete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取请求参数中图书的id
        String id = req.getParameter("id");
        //通过id删除图书
        bookService.deleteBookById(Integer.valueOf(id));
        //跳转回展示页面
        resp.sendRedirect(req.getContextPath()+"/manager/bookServlet?action=page&pageNo="+req.getParameter("pageNo"));

    }

    /**
     * 更新图书信息
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void update(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取请求参数，封装成bean
        Book book=WebUtils.copyParamToBean(req.getParameterMap(),new Book());
        //调用BookService.update(book) 修改图书
        bookService.updateBook(book);
        //重定向到图书列表页面
        resp.sendRedirect(req.getContextPath()+"/manager/bookServlet?action=page&pageNo="+req.getParameter("pageNo"));
    }

    /**
     * 展示所有图书
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void list(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
          //1通过BookService查询所有图书
        List<Book> books =bookService.queryBooks();
          //2把图书信息写入request域
        req.setAttribute("books",books);
          //3请求转发到/pages/manager/book_manager/jsp
        req.getRequestDispatcher("/pages/manager/book_manager.jsp").forward(req,resp);
    }

    /**
     *  通过id获取图书信息，并且返回到图书编辑页面（修改图书信息业务）
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void getBook(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取请求的参数图书编号
        String id = req.getParameter("id");
        //调用bookService.queryBookById获取图书信息
         Book book = bookService.queryBookById(Integer.valueOf(id));
        //保存图书到Request域中
        req.setAttribute("book",book);

        //请求转发到 pages/manager/book_edit.jsp
       //由于getBook的转发是请求转发，从book_manager转发过来的请求中带有pageNo，可以直接转发，不添加pageNo属性
        req.getRequestDispatcher("/pages/manager/book_edit.jsp").forward(req,resp);
    }

    /**
     * 处理分页功能
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void page(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //1获取请求的参数 pageNo pageSize, 默认第一页开始展示
        int pageNo =WebUtils.parseInt(req.getParameter("pageNo"),1);
        int pageSize =WebUtils.parseInt(req.getParameter("pageSize"),Page.PAGE_SIZE);
        //2调用BookService.page(pageNo,pageSize) 获得page对象
        Page<Book> page = bookService.page(pageNo,pageSize);
        //设置page的url
        page.setUrl("manager/bookServlet?action=page");
        //保存page对象到request域
        req.setAttribute("page",page);
        //请求转发到 pages/manager/book_manager.jsp
        req.getRequestDispatcher("/pages/manager/book_manager.jsp").forward(req,resp);
    }
}
