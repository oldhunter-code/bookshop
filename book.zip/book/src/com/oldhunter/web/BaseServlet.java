package com.oldhunter.web;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.Method;
//定义成抽象类是因为，抽象类不能被实例化
public abstract class BaseServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //解决psot提交的乱码问题，get提交乱码tomcat9后的版本已经解决了
        req.setCharacterEncoding("UTF-8");
        //响应的中文乱码
        resp.setContentType("text/html;charset=UTF-8");
        String action = req.getParameter("action");
        //注意：访问继承了这个类的servlet，请求中一定要带有action域，不然会有空指针异常（debug）
        //获取action业务鉴别字符，通过反射获取相应的业务方法 方法反射对象,HttpServletRequest.Class和httpservletresponse.class是参数,
        try {
            Method method = this.getClass().getDeclaredMethod(action, HttpServletRequest.class,HttpServletResponse.class);
            //利用反射机制调用目标业务方法
            method.invoke(this,req,resp);
        } catch (Exception e) {
            e.printStackTrace();
            //Servlet中执行业务方法，调用Service层的方法，如果发生异常，会把异常向上抛，最终会在这里被捕获，我们需要继续把异常上抛，最终才能执行事务回滚
            throw new RuntimeException(e);
        }


    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }
}
