package com.oldhunter.web;

import com.oldhunter.pojobean.Cart;
import com.oldhunter.pojobean.User;
import com.oldhunter.service.OrderService;
import com.oldhunter.service.serviceImp.OrderServiceImpl;
import com.oldhunter.utils工具类.JdbcUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "OrderServlet",urlPatterns = "/orderServlet")
public class OrderServlet extends BaseServlet {
     OrderService orderService = new OrderServiceImpl();
    /**
     * 生成订单
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void createOrder(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
     //获取session域中的购物车信息
        Cart cart = (Cart) req.getSession().getAttribute("cart");
     // 获取user信息
        User user = (User) req.getSession().getAttribute("user");
        //如果用户还没有登录，跳转到登录页面
        if(user==null){
            req.getRequestDispatcher("/pages/user/login.jsp").forward(req,resp);
            return;
        }
       //调用service生成订单
        String orderId = orderService.createOrder(cart, user.getId());

        req.getSession().setAttribute("orderId",orderId);
        resp.sendRedirect(req.getContextPath()+"/pages/cart/checkout.jsp");
    }
}
