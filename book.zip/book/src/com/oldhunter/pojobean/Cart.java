package com.oldhunter.pojobean;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 购物车对象
 */

public class Cart {
    //private Integer totalCount;//购物车商品总数量
   // private BigDecimal totalPrice;//购物车商品总价
    //key是商品id value 是商品信息
    private Map<Integer,CartItem> items=new LinkedHashMap<Integer, CartItem>();

    public Integer getTotalCount() {
       Integer totalCount=0;
       for(Map.Entry<Integer,CartItem> entry:items.entrySet()){
           totalCount+= entry.getValue().getCount();
       }
       return totalCount;
    }



    public BigDecimal getTotalPrice() {
       BigDecimal totalPrice=new BigDecimal(0);
        for(Map.Entry<Integer,CartItem> entry:items.entrySet()){
          totalPrice=totalPrice.add(entry.getValue().getTotalPrice());
         }
        return totalPrice;
    }


    @Override
    public String toString() {
        return "Cart{" +
                "totalCount=" + getTotalCount() +
                ", totalPrice=" + getTotalPrice() +
                ", items=" + items +
                '}';
    }

    /**
     * key是商品编号
     * value 是商品信息
     * @return
     */
    public Map<Integer,CartItem> getItems() {
        return items;
    }

    public void setItems(Map<Integer,CartItem> items) {
        this.items = items;
    }



    /**
     * 添加商品项
     * @param cartItem
     */
    public void addItem(CartItem cartItem ){
        //查看购物车是否已经添加过此商品，如果已经添加过，数量累加，如果没有添加过，直接加到集合
        CartItem item = items.get(cartItem.getId());
        //如果没添加过
        if (item==null){
            items.put(cartItem.getId(),cartItem);
        }else {
            //添加过
            item.setCount(item.getCount()+1);
            item.setTotalPrice(item.getPrice().multiply(new BigDecimal(item.getCount())));
        }

    }


    /**
     * 删除商品项
     * @param id
     */
    public void deleteItem(Integer id){
      items.remove(id);
    }

    /**
     * 清空购物车
     */
    public void  clear(){
      items.clear();
    }

    /**
     * 修改商品数量
     * @param id
     * @param count
     */
    public void  updateCount(Integer id,Integer count){
      //先查看购物车中是否有该商品 ，如果有，修改商品数量，更新总金额
        CartItem cartItem = items.get(id);
        if (cartItem!=null){
            cartItem.setCount(count);
            cartItem.setTotalPrice(cartItem.getPrice().multiply(new BigDecimal(cartItem.getCount())));
        }
    }
}


