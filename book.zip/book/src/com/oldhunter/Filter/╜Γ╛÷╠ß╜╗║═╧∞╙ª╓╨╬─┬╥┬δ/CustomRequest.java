//package com.oldhunter.Filter.解决提交和响应中文乱码;
//
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletRequestWrapper;
//import java.util.*;
//
////首先创建HttpRequest的实现类的装饰者子类
////装饰者基类是HttpRequestWrapper
////要求 要继承装饰者基类
////        要有带参构造器
////        具体装饰者支队装饰者基类业务方法进行某一类的增强
//public class CustomRequest extends HttpServletRequestWrapper {
//
//    public CustomRequest(HttpServletRequest request){
//        super(request);
//    }
//
//    //重写方法
//    //要将原始的map替换为自定义的map
//    //修改原始map的乱码修正后传入新的map
//    public Map<String,String[]> getParameterMap(){
//        //新建一个map
//        Map<String,String[]> newMap = new HashMap<>();
//        //获取原始的map,其数据是乱码
//        Map<String,String[]> originalMap = super.getParameterMap();
//        //将原始map中的乱码解决后放入新的map
//        //遍历
//        try{
//            for(String key : originalMap.keySet()){
//                //获取当前 遍历key的所有值
//                String[] values = originalMap.get(key);
//                //遍历values数组，对每一个值进行中文乱码问题解决
//                for(int i =0;i<values.length;i++){
//                    //按照字符当前的编码打散（ISO8859-1）需要进行异常处理
//                    byte[] bytes=values[i].getBytes("ISO8859-1");
//                    //按照目标编码组装
//                    values[i] = new String(bytes,"UTF-8");
//
//                }
//                //将解决了乱码问题的数据加入新的map
//                newMap.put(key,values);
//            }
//        }catch(Exception e){
//            e.printStackTrace();
//        }
//
//        //返回新的map
//        return newMap;
//    }
//
//    public Enumeration<String> getParameterNames(){
//        Map<String, String[]> map = this.getParameterMap();
//        Set<String> keySet = map.keySet();
//        Vector keyVector=(Vector) keySet;
//        return keyVector.elements();
//
//    }
//    public String[] getParameterValues(String name){
//        //获取自定义的parameterMap
//        Map<String,String[]> map = this.getParameterMap();
//        return map.get(name);
//    }
//    public String getParameter(String name){
//        return this.getParameterValues(name)[0];
//    }
//}
//
