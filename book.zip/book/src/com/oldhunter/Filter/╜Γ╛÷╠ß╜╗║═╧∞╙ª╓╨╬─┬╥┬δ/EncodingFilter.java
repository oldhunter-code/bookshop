//package com.oldhunter.Filter.解决提交和响应中文乱码;
//
//import javax.servlet.*;
//import javax.servlet.annotation.WebFilter;
//import javax.servlet.http.HttpServletRequest;
//import java.io.IOException;
//@WebFilter(filterName = "EncodingFilter",urlPatterns = "/*")
//public class EncodingFilter implements Filter {
//    @Override
//    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
//      request=new MyRequest((HttpServletRequest) request);
//      response.setContentType("text/html;charset=UTF-8");
//      chain.doFilter(request,response);
//    }
//
//    @Override
//    public void init(FilterConfig filterConfig) throws ServletException {
//
//    }
//
//    @Override
//    public void destroy() {
//
//    }
//}
