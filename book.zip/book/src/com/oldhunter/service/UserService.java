package com.oldhunter.service;

import com.oldhunter.pojobean.User;

public interface UserService {
    /**
     * 注册
     * @param user
     */
    public void  registUser(User user);

    /**
     *  登录
     * @param user
     * @return
     */
    public  User login(User user);

    /**
     * 检查用户名是否已存在
     * @param username
     * @return 返回true表明用户名已存在，否则用户名可用
     */
    public  boolean existUsername(String username);
}
