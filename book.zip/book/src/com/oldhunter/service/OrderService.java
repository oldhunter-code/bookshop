package com.oldhunter.service;

import com.oldhunter.pojobean.Cart;

public interface OrderService {
    String createOrder(Cart cart,Integer userId);
}
