package com.oldhunter.service.serviceImp;

import com.oldhunter.dao.BookDao;
import com.oldhunter.dao.OrderDao;
import com.oldhunter.dao.OrderItemDao;
import com.oldhunter.dao.daoImpl.BookDaoImpl;
import com.oldhunter.dao.daoImpl.OrderDaoImpl;
import com.oldhunter.dao.daoImpl.OrderItemDaoImpl;
import com.oldhunter.pojobean.*;
import com.oldhunter.service.OrderService;

import java.util.Date;
import java.util.Map;

public class OrderServiceImpl implements OrderService {

    private OrderDao orderDao = new OrderDaoImpl();
    private OrderItemDao orderItemDao = new OrderItemDaoImpl();
    private BookDao bookDao= new BookDaoImpl();
    @Override
    public String createOrder(Cart cart, Integer userId) {
        //先保存订单
        //利用时间戳和用户id创建唯一订单号
        String orderId=System.currentTimeMillis()+""+userId;
        Order order = new Order(orderId,new Date(),cart.getTotalPrice(),0,userId);
        orderDao.saveOrder(order);
        //保存订单项，把购物车的cart.items 转换成订单项
        for (Map.Entry<Integer, CartItem> entry:cart.getItems().entrySet()) {
             //获取购物车的商品项
            CartItem cartItem = entry.getValue();
            //商品项转换成订单项
            OrderItem orderItem = new OrderItem(null,cartItem.getName(),cartItem.getCount(),cartItem.getPrice(),cartItem.getTotalPrice(),orderId);
             //保存订单项到数据库
            orderItemDao.saveOrderItem(orderItem);
            //修改商品的销量和库存
            Book book = bookDao.queryBookById(cartItem.getId());
            book.setSales(book.getSales()+cartItem.getCount());
            book.setStock(book.getStock()-cartItem.getCount());
            bookDao.updateBook(book);
        }
        //生成订单后清空购物车
        cart.clear();
       //返回订单号
        return orderId;
    }
}
