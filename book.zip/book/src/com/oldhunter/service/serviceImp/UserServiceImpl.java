package com.oldhunter.service.serviceImp;

import com.oldhunter.dao.UserDao;
import com.oldhunter.dao.daoImpl.UserDaoImpl;
import com.oldhunter.pojobean.User;
import com.oldhunter.service.UserService;

public class UserServiceImpl implements UserService {

    //需要一个UserDao操作数据库
    private UserDao userDao = new UserDaoImpl();
    @Override
    public void registUser(User user) {
        userDao.saveUser(user);
    }

    @Override
    public User login(User user) {
        return userDao.queryUserByUsernameAndPassword(user.getUsername(),user.getPassword());

    }

    @Override
    public boolean existUsername(String username) {
        if (userDao.queryUserByUsername(username)==null){
            return false;
        }
        return true;
    }
}
