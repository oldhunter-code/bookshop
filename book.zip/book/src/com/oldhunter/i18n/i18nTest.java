package com.oldhunter.i18n;

import org.junit.Test;

import java.util.Locale;

public class i18nTest {
    @Test
    public void testLocal() {
        //获取系统默认的语言，国家信息
        Locale locale = Locale.getDefault();
        System.out.println(locale);


        //获取中文，中文的常量local对象
        System.out.println(Locale.CANADA);
        //获取英文，英文的常量local对象
        System.out.println(Locale.US);
    }
}
