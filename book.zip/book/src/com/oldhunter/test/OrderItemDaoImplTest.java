package com.oldhunter.test;

import com.oldhunter.dao.OrderItemDao;
import com.oldhunter.dao.daoImpl.OrderItemDaoImpl;
import com.oldhunter.pojobean.OrderItem;
import org.junit.Test;

import java.math.BigDecimal;

import static org.junit.Assert.*;

public class OrderItemDaoImplTest {
    OrderItemDao orderItemDao = new OrderItemDaoImpl();
    @Test
    public void saveOrderItem() {
        orderItemDao.saveOrderItem(new OrderItem(null,"java",1,new BigDecimal(100),new BigDecimal(100),"123456789"));
        orderItemDao.saveOrderItem(new OrderItem(null,"javaScript",1,new BigDecimal(100),new BigDecimal(100),"123456789"));
    }
}