package com.oldhunter.test;

import com.oldhunter.pojobean.Book;
import com.oldhunter.pojobean.Page;
import com.oldhunter.service.BookService;
import com.oldhunter.service.serviceImp.BookServiceImpl;
import org.junit.Test;

import java.math.BigDecimal;

import static org.junit.Assert.*;

public class BookServiceTest {
    private BookService bookService = new BookServiceImpl();

    @Test
    public void addBook() {
        bookService.addBook(new Book(null, "python1", "odlhunter", new BigDecimal(100), 9999, 99, "static/img/default.img"));
    }

    @Test
    public void deleteBookById() {
        bookService.deleteBookById(20);
    }

    @Test
    public void updateBook() {
        bookService.updateBook(new Book(26, "python4", "odlhunter", new BigDecimal(100), 9999, 99, "static/img/default.img"));
    }

    @Test
    public void queryBookById() {
        System.out.println(bookService.queryBookById(26));
    }

    @Test
    public void queryBooks() {
        System.out.println(bookService.queryBooks());
    }

    @Test
    public void page() {
        System.out.println(bookService.page(1, Page.PAGE_SIZE));
    }
    @Test
    public void pageByPrice() {
        System.out.println(bookService.pageByPrice(1, Page.PAGE_SIZE,10,50));
    }
}