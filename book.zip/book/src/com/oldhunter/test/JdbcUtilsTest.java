package com.oldhunter.test;

import com.oldhunter.utils工具类.JdbcUtils;
import org.junit.Test;

public class JdbcUtilsTest {
    /**
     * junit测试
     */
    @Test
    public void  testJdbcUtils(){
        System.out.println(JdbcUtils.getConnection());
    }
}
