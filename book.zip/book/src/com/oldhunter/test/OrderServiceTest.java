package com.oldhunter.test;

import com.oldhunter.pojobean.Cart;
import com.oldhunter.pojobean.CartItem;
import com.oldhunter.service.OrderService;
import com.oldhunter.service.serviceImp.OrderServiceImpl;
import org.junit.Test;

import java.math.BigDecimal;

import static org.junit.Assert.*;

public class OrderServiceTest {
    OrderService orderService = new OrderServiceImpl();
    @Test
    public void createOrder() {
        Cart cart = new Cart();
        cart.addItem(new CartItem(1,"java",1,new BigDecimal(1000),new BigDecimal(1000)));
        cart.addItem(new CartItem(1,"java",1,new BigDecimal(1000),new BigDecimal(1000)));
        cart.addItem(new CartItem(2,"数据结构",1,new BigDecimal(1000),new BigDecimal(1000)));
        System.out.println("订单号是："+orderService.createOrder(cart,1));

    }
}