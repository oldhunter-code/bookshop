package com.oldhunter.test;

import com.oldhunter.pojobean.User;
import com.oldhunter.service.UserService;
import com.oldhunter.service.serviceImp.UserServiceImpl;
import org.junit.Test;

import static org.junit.Assert.*;

public class UserServiceTest {
    UserService userService = new UserServiceImpl();
    @Test
    public void registUser() {
        userService.registUser(new User(null,"bbbj168","666666","168.com"));
    }

    @Test
    public void login() {
        System.out.println( userService.login(new User(null,"admin","admin111",null)));
    }

    @Test
    public void existUsername() {
        if(userService.existUsername("admin")==true){
            System.out.println("用户名已存在");
        }else {
            System.out.println("用户名可用");
        }

    }
}