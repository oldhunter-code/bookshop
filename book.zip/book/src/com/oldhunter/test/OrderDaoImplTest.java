package com.oldhunter.test;

import com.oldhunter.dao.OrderDao;
import com.oldhunter.dao.daoImpl.OrderDaoImpl;
import com.oldhunter.pojobean.Order;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.Date;

import static org.junit.Assert.*;

public class OrderDaoImplTest {
    OrderDao orderDao = new OrderDaoImpl();
    @Test
    public void saveOrder() {
    orderDao.saveOrder(new Order("123456789",new Date(),new BigDecimal(110),0,1 ));

    }
}