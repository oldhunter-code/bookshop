package com.oldhunter.test;

import com.oldhunter.dao.BookDao;
import com.oldhunter.dao.daoImpl.BookDaoImpl;
import com.oldhunter.pojobean.Book;
import com.oldhunter.pojobean.Page;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.Assert.*;

public class BookDaoTest {

    private BookDao bookDao=new BookDaoImpl();
    @Test
    public void addBook() {
       bookDao.addBook(new Book(null,"python","odlhunter",new BigDecimal(100),9999,99,"static/img/default.img"));
    }

    @Test
    public void deleteBookById() {
        bookDao.deleteBookById(25);
    }

    @Test
    public void updateBook() {
        bookDao.updateBook(new Book(26,"python3","odlhunter",new BigDecimal(100),9999,99,"static/img/default.img"));
    }

    @Test
    public void queryBookById() {
        System.out.println(bookDao.queryBookById(26));
    }

    @Test
    public void queryBooks() {
        List<Book> list = bookDao.queryBooks();
        System.out.println(list);
    }
    @Test
    public void queryForPageTotalCount() {
        System.out.println(bookDao.queryForPageTotalCount());
    }

    @Test
    public void  queryForPageItems() {
       List<Book> list=bookDao.queryForPageItems(0,4);
        System.out.println(list);
    }
    @Test
    public void queryForPageTotalCountByPrice(){
        System.out.println(bookDao.queryForPageTotalCountByPrice(10,50));
    }
    @Test
    public void  queryForPageItemsByPrice() {
        List<Book> list=bookDao.queryForPageItemsByPrice(0, Page.PAGE_SIZE,10,50);
        System.out.println(list);
    }


}